# HSK 3 Learning Hub v3

Bản này sửa lỗi cache/mismatch bằng cách đổi tên file:
- `style-v3.css`
- `data-v3.js`
- `app-v3.js`

Ngoài dữ liệu trước đó, đã bổ sung một số mục từ trong giáo trình bị bỏ sót:
- 奥运会, 刘长春
- 老张
- 英国
- 南京, 黄河
- 草地, 蓝天

## Cách cập nhật GitHub
Upload toàn bộ:
- index.html
- style-v3.css
- data-v3.js
- app-v3.js

Có thể giữ file cũ hoặc xóa sau. `index.html` mới chỉ gọi file v3 nên tránh trình duyệt dùng nhầm JS/CSS cũ.
